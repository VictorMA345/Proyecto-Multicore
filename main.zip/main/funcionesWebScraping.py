from imports import *
def validarBusqueda(string):
    string = string.lower()
    string = string.replace(" ","-")
    string = string.replace("'","")
    return string
def obtenerPrecioSteam(url):
    try:
        usuario = {'User-agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0'}
        url1 = requests.get(url,headers=usuario)
        soup = bs(url1.text,'html.parser')
        info =soup.findAll('script',attrs= {'type':'application/ld+json'})
        info_sel = info[0]
        info1 = str(info_sel.contents[0])
        precio = json.loads(info1)
        sacar = precio['offers'] 
        precio1 = sacar['price']
        return precio1
    except: 
        return 'juego no encontrado'
def obtenerinfoMetacritic(url):
    user_agent = {'User-agent': 'Mozilla/5.0'}
    response = requests.get(url, headers = user_agent)
    soup = bs(response.text, 'html.parser')
    lala = soup.find('script',attrs={"type":"application/ld+json"})
    info1 = str(lala.contents[0])
    info = json.loads(info1)
    rate = info['aggregateRating']
    publicador1 = info['publisher']
    publicador = publicador1[0]
    genero = info['genre']
    info_Juego={'nombre':info['name'],'descripcion':info['description'],'puntaje':rate['ratingValue'],'desarrolladora': publicador['name']}
    return info_Juego
#Recives a the string obteined from the web scrapping
#This function is specially for the games that have not discounts
#Returns the final price
def cleanFinalPrice(price):
    price = str(price)
    price = price.replace('<span class="psw-h3" data-qa="mfeCtaMain#offer0#finalPrice">US',"")
    price = price.replace("</span>","")
    return price

#Recives a the string obteined from the web scrapping
#This function is used IF there is some discount in the game
#Returns the final price
def cleanOriginalPrice(originalPrice):
    originalPrice = str(originalPrice)
    originalPrice = originalPrice.replace('<span class="psw-h4 psw-c-secondary psw-text-strike-through" data-qa="mfeCtaMain#offer0#originalPrice">US',"")
    originalPrice = originalPrice.replace("</span>","")
    return originalPrice


#Main function that executes the web scrapping and return all the data cleaned
#Recives the URL of the PlayStation web of the game you want to stract the price.
def extraePrecioPlay(url):
    userAgent = {'User-agent':'Mozilla/5.0'}#This helps to enter the page without errors
    req = requests.get(url,headers = userAgent)
    soup = bs(req.text,'html.parser')
    
    finalPrice = soup.find_all('span',attrs = {"data-qa":"mfeCtaMain#offer0#finalPrice"})[0]#The actual price of the game
    finalPrice = cleanFinalPrice(finalPrice)

    originaPrice = None #In case there is some discount
    if(soup.find_all('span',attrs = {"data-qa":"mfeCtaMain#offer0#originalPrice"})):#If there is a discount
        originaPrice = soup.find_all('span',attrs = {"data-qa":"mfeCtaMain#offer0#originalPrice"})[0]#In case there are some discount
        originaPrice = cleanOriginalPrice(originaPrice)


    arrPrices = [originaPrice,finalPrice]

    return arrPrices
#Recives the string stracted by the scrapping and cleans it until it has only the information we need.
#Returns an array that contains the category and the amount of hours need to complete the game in the corresponding category.
def separaInfo(stringInfo):
    #Cleaning the string
    stringInfo = str(stringInfo)
    stringInfo = stringInfo.replace('<li class="short time_100">',"")
    stringInfo = stringInfo.replace("<h5>","")
    stringInfo = stringInfo.replace("</h5>"," ")
    stringInfo = stringInfo.replace("<div>","")
    stringInfo = stringInfo.replace("</div>","")
    stringInfo = stringInfo.replace("</li>","")

    splited = stringInfo.split("\n")#We need to split it to return the category and the amount of hours separated into a string
    title = splited[1]
    hours = splited[2]

    info = [title,hours]
    return info

#Returns an array that have all the information we need.
#Recives the array extracted by the web scraping.
def creaArrInfo(arrElements):
    #We separete the given information into their different categories used
    mainStory = separaInfo(arrElements[0])
    #mainPExtras = separaInfo(arrElements[1])
    #completionist = separaInfo(arrElements[2])
   # speedRun = separaInfo(arrElements[3])

    #arrInfo = [mainStory,mainPExtras,completionist,speedRun]
    arrInfo = mainStory
    return arrInfo

#Do the web scrapping and return the information in an array
def extraeTiempoPasar(url):
    try:
        userAgent = {'User-agent':'Mozilla/5.0'}#This helps to enter the page without errors
        req = requests.get(url,headers = userAgent)
        soup = bs(req.text,'html.parser')
        times = soup.find_all('li',attrs = {"class":"short time_100"})
   
        if(len(times) == 0):
            times = soup.find_all('li',attrs = {"class":"short time_50"})

        arrInfo = creaArrInfo(times)

        return arrInfo
    except:
        return 'juego no encontrado'
